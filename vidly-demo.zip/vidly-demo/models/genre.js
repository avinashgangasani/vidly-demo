const mongoose = require('mongoose');
const Joi = require('joi');

const genreSchema = new mongoose.Schema({
    name: { type: String, required: true, minlength: 3, maxlength: 100 }
})
const Genre = mongoose.model('Genre', genreSchema);

function validateGenre(params) {
    console.log('Validating model...');
    const schema = Joi.object({
        id: Joi.string().min(1),
        name: Joi.string().min(3).max(10).required()
    })
    return schema.validate(params);
}

exports.Genre = Genre;
exports.validate = validateGenre;
exports.genreSchema = genreSchema;