const Joi = require('joi');
const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
    isGold: { type: Boolean, default: false },
    name: { type: String, min: 3, max: 10, required: true },
    phone: { type: Number, required: true, minlength: 10, maxlength: 10 }
});
const Customer = mongoose.model('Customer', customerSchema);

function validateCustomer(params) {
    console.log('Validating model...');
    const schema = Joi.object({
        id: Joi.string().min(1),
        isGold: Joi.boolean().default(false),
        name: Joi.string().min(3).max(10).required(),
        phone: Joi.number().required()
    })
    return schema.validate(params);
}

exports.Customer = Customer;
exports.validate = validateCustomer;