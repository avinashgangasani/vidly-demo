const mongoose = require('mongoose');

const rentalSchema = new mongoose.Schema({
    customer: {
        type: new mongoose.Schema({
            name: { type: String, minlength: 3, maxlength: 100, required: true },
            isGold: { type: Boolean, required: true, default: false },
            phone: { type: Number, minlength: 10, maxlength: 10 }
        }), required: true
    },
    movie: {
        type: new mongoose.Schema({
            title: { type: String, minlength: 3, maxlength: 100, required: true },
            numberInStock: { type: Number },
            dailyRentalRate: { type: Number }
        }), required: true
    },
    dateOut: { type: Date },
    dateReturned: { type: Date },
    rentalFee: { type: Number }
})

const Rental = mongoose.model('Rental', rentalSchema);

module.exports.Rental = Rental;