const express = require('express');
const process = require('process');
const logger = require('./middleware/logger');
const morgan = require('morgan');//Go through this package documentation
const helmet = require('helmet');//Go through this package documentation
const { model } = require('mongoose');
//const winston = require('winston');//error logging framework, commenting as it does not work with integration testing
require('express-async-errors');//use of this can avoid the necessity of using asyncmiddleware function

const app = express();

//Loading initial config settings
require('./startup/initconfig')(process, app);

app.set('view engine', 'pug');//set the view engine
app.set('views', './views');//set the views path of view engine

//integrate middleware
app.use(express.json());
app.use(logger);
app.use(express.static('public-content'));
app.use(helmet());
app.use(morgan('tiny'));

//Logging uncaught exceptions and unhandled rejections
require('./startup/logging')(process);

//command to shutdown mongodb server: mongo admin --eval "db.shutdownServer()"
//DB connection setup below
require('./startup/dbconnection')();

//integrate routes
//Set the base route and the related route object
require('./startup/routes')(app);

//Prod ready libraries
require('./startup/prod')(app);

const port = process.env.PORT || 3000;
const server = app.listen(port, () => {
    console.log(`Listening on port ${port}...`)
});

module.exports = server;




