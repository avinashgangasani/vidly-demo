const request = require('supertest');
const {Genre} = require('../../models/genre');
let server;

//Comment authorize function in the routers before you run the tests

describe('Genres APIs', () => {
    beforeEach(() => {server = require('../../app');});
    afterEach(() => {server.close()})
    Genre.collection.deleteMany({});

    describe('GET /', () => {
        it('Should return all genres', async () => {
            Genre.collection.insertMany(
                [{name: 'Genre1'},
                 {name: 'Genre2'}]);

            const res = await request(server).get('/api/genres');
            expect(res.status).toBe(200);
            expect(res.body.result.length).toBe(2);
            expect(res.body.result.some(g => g.name==='Genre1'));
            expect(res.body.result.some(g => g.name==='Genre2'));
        });
    })

    describe('GET /:id', () => {
        it('Should return the selected genre', async () => {
            let genre = new Genre({name: 'Genre1'})
            await genre.save();

            const res = await request(server).get(`/api/genres/${genre._id}`);
            expect(res.status).toBe(200);
            expect(res.body.result).toHaveProperty('name', genre.name);
        });
    })

    describe('GET /:id', () => {
        it('Should not return any genre for invalid ID', async () => {            
            const dummyID = 'abcd';
            const res = await request(server).get(`/api/genres/${dummyID}`);
            expect(res.status).toBe(404);
        });
    })
})