const jwt = require('jsonwebtoken');
const config = require('config');

function authorize(request, response, next) {
    const jwtToken = request.header('x-user-token');

    if(!jwtToken) return response.status(401).send('Authentication token missing.');

    try{
        const payload = jwt.verify(jwtToken, config.get('jwtPrivateKey'));
        request.user = payload;
        console.log(request.user);
        next();
    }
    catch(error)
    {
       return response.status(401).send('Authentication token invalid.');
    }    
    //next();
}
module.exports = authorize;

/*Anu
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZmUzZjRhMjhkNjI0ZTIzOTQ1YmMwMjUiLCJpc0FkbWluIjp0cnVlLCJpYXQiOjE2MDg4NDM5NzJ9.2Y1MMg4F3vohVrzEqENy4EITgGAx4YwYfk9L8PqHK2E
*/

/*Avi
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZmU0ZjMxNWMxZWM1ZTQ3N2MyYTIzNWMiLCJpYXQiOjE2MDg4NDQxNjl9.F6WA_cm7TX5AtvUAz-72UA-tAEvfIgsLYJeot87grUw
*/