function adminAuth(request, response, next) {
    //console.log(request.user.isAdmin);
    if (!request.user.isAdmin) return response.status(403).send('User has to been an Admin to perform this operation.');
    next();
}
module.exports = adminAuth;