function log(request, response, next) {
    //request.body.logged = true;
    console.log('Logging...');
    next();
}
module.exports = log;