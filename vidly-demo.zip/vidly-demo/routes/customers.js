const express = require('express');
const router = express.Router();
const { Customer, validate } = require('../models/customer');
const authorize = require('../middleware/authorization');

router.get('/', authorize, async (request, response) => {
    const customer = await Customer.find();
    response.send({ customer: customer, requestBody: request.body });
});

router.get('/:id', authorize, async (request, response) => {
    console.log('Calling GET...');
    const customer = await Customer.findById(request.params.id);

    if (customer) {
        console.log('Record found...');
        response.send({ result: customer, requestBody: request.body });
    }
    else {
        console.error('Error occurred...');
        response.status(404).send({ message: "Record not found", requestBody: request.body });
    }
});

router.post('/', authorize, async (request, response) => {
    console.log('Calling POST...');
    const result = validate(request.body);

    if (result.error) {
        console.error('Error occurred...');
        response.status(400).send(JSON.stringify({ error: result.error, requestBody: request.body }));
    }
    else {
        console.log('Updating model...');
        const customer = new Customer({
            isGold: request.body.isGold,
            name: request.body.name,
            phone: request.body.phone
        })
        try {
            console.log('Validating schema...');
            console.log('Saving record..');
            const output = await customer.save();
            console.log('Record saved...');
            response.send({ result: output, requestBody: request.body });
        }
        catch (error) {
            response.status(400).send(JSON.stringify({ error: error.message, requestBody: request.body }));
        }
    }
});

router.put('/', authorize, async (request, response) => {
    console.log("Calling PUT...");
    const result = validate(request.body);

    if (result.error) {
        console.error('Error occurred...');
        response.status(400).send({ error: result.error, requestBody: request.body });
    }
    else {
        try {
            console.log('Updating model...');
            const customer = Customer.findById(request.body.id);

            if (customer) {
                try {
                    console.log('Record found...');
                    console.log('Updating record...');
                    const output = await Customer.findByIdAndUpdate(request.body.id,
                        {
                            $set: {
                                isGold: request.body.isGold,
                                name: request.body.name,
                                phone: request.body.phone
                            }
                        },
                        { new: true });
                    response.send({ result: output, requestBody: request.body });
                }
                catch (error) {
                    response.send({ result: "Error occurred", requestBody: request.body });
                }
            }
            else {
                console.error('Record not found...');
                response.status(404).send({ error: "Record not found", requestBody: request.body });
            }
        }
        catch (error) {
            console.error('Error occurred...');
            response.status(400).send({ error: error.message, requestBody: request.body });
        }
    }
});

router.delete('/:id', authorize, async (request, response) => {
    console.log('Calling DELETE...');
    const customer = Customer.findById(request.params.id);
    if (customer) {
        try {
            const output = await Customer.findByIdAndDelete(request.params.id);
            response.send({ result: output, requestBody: request.body });
        }
        catch (error) {
            response.send({ result: error.message, requestBody: request.body });
        }
    }
    else {
        console.error('Record not found...');
        response.status(400).send({ error: result.error, requestBody: request.body });
    }
});

module.exports = router;