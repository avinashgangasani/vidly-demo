const express = require('express');
const router = express.Router();

//Render data in a template engine
router.get('/', (request, response) => {
    response.render('index', {title: 'Vidly Application', message: 'Hello World'})
});

module.exports = router;