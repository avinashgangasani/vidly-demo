const express = require('express');
const { Movie } = require('../models/movie');
const router = express.Router();
const authorize = require('../middleware/authorization');

router.get('/', authorize, async (request, response) => {
    const movies = await Movie.find();
    response.send({ movies: movies, requestBody: request.body });
});

router.get('/:id', authorize, async (request, response) => {
    console.log('Calling GET...');
    const movie = await Movie.findById(request.params.id);

    if (movie) {
        console.log('Record found...');
        response.send({ result: movie, requestBody: request.body });
    }
    else {
        console.error('Error occurred...');
        response.status(404).send({ message: "Record not found", requestBody: request.body });
    }
});

router.post('/', authorize, async (request, response) => {
    console.log('Calling POST...');

    console.log('Updating model...');
    console.log(request.body.genre);
    const movie = new Movie({
        title: request.body.title,
        genre: request.body.genre,
        numberInStock: request.body.numberInStock,
        dailyRentalRate: request.body.dailyRentalRate
    });
    try {
        console.log('Validating schema...');
        console.log('Saving record..');
        const output = await movie.save();
        console.log('Record saved...');
        response.send({ result: output, requestBody: request.body });
    }
    catch (error) {
        response.status(400).send(JSON.stringify({ error: error.message, requestBody: request.body }));
    }
});

router.put('/', authorize, async (request, response) => {
    console.log("Calling PUT...");
    try {
        console.log('Updating model...');
        const movie = Movie.findById(request.body.id);

        if (movie) {
            try {
                console.log('Record found...');
                console.log('Updating record...');
                const output = await Movie.findByIdAndUpdate(request.body.id,
                    {
                        $set: {
                            title: request.body.title,
                            genre: request.body.genre,
                            numberInStock: request.body.numberInStock,
                            dailyRentalRate: request.body.dailyRentalRate
                        }
                    },
                    { new: true });
                response.send({ result: output, requestBody: request.body });
            }
            catch (error) {
                response.send({ result: "Error occurred", requestBody: request.body });
            }
        }
        else {
            console.error('Record not found...');
            response.status(404).send({ error: "Record not found", requestBody: request.body });
        }
    }
    catch (error) {
        console.error('Error occurred...');
        response.status(400).send({ error: error.message, requestBody: request.body });
    }
});

router.delete('/:id', authorize, async (request, response) => {
    console.log('Calling DELETE...');
    const movie = Movie.findById(request.params.id);
    if (movie) {
        try {
            const output = await Movie.findByIdAndDelete(request.params.id);
            response.send({ result: output, requestBody: request.body });
        }
        catch (error) {
            response.send({ result: error.message, requestBody: request.body });
        }
    }
    else {
        console.error('Record not found...');
        response.status(400).send({ error: result.error, requestBody: request.body });
    }
});

module.exports = router;