const express = require('express');
const router = express.Router();
const { Genre, validate } = require('../models/genre');
const authorize = require('../middleware/authorization');
const checkIfAdmin = require('../middleware/admin-auth');
const asyncMiddleware = require('../middleware/trycatch');
const mongoose = require('mongoose');
const objectIdValidation = require('../middleware/objectIdValidation');

// 
router.get('/', authorize, async (request, response) => {
    const genres = await Genre.find();
    console.log("came here..")
    response.send({ result: genres, requestBody: request.body });
});

//authorize, 
router.get('/:id', authorize, objectIdValidation, async (request, response) => {
    console.log('Calling GET...');    
    const genre = await Genre.findById(request.params.id);
    if (genre) {
        console.log('Record found...');
        response.send({ result: genre, requestBody: request.body });
    }
    else {
        console.error('Error occurred...');
        response.status(404).send({ message: "Record not found", requestBody: request.body });
    }
});

router.post('/', [authorize, checkIfAdmin], async (request, response) => {
    console.log('Calling POST...');
    const result = validate(request.body);

    if (result.error) {
        console.error('Error occurred...');
        response.status(400).send(JSON.stringify({ error: result.error, requestBody: request.body }));
    }
    else {
        console.log('Updating model...');
        const genre = new Genre({
            name: request.body.name
        })
        try {
            console.log('Validating schema...');
            console.log('Saving record..');
            const output = await genre.save();
            console.log('Record saved...');
            response.send({ result: output, requestBody: request.body });
        }
        catch (error) {
            response.status(400).send(JSON.stringify({ error: error.message, requestBody: request.body }));
        }
    }
});

router.put('/', [authorize, checkIfAdmin], async (request, response) => {
    console.log("Calling PUT...");
    const result = validate(request.body);

    if (result.error) {
        console.error('Error occurred...');
        response.status(400).send({ error: result.error, requestBody: request.body });
    }
    else {
        try {
            console.log('Updating model...');
            const genre = Genre.findById(request.body.id);

            if (genre) {
                try {
                    console.log('Record found...');
                    console.log('Updating record...');
                    const output = await Genre.findByIdAndUpdate(request.body.id,
                        { $set: { name: request.body.name } },
                        { new: true });
                    response.send({ result: output, requestBody: request.body });
                }
                catch (error) {
                    response.send({ result: "Error occurred", requestBody: request.body });
                }
            }
            else {
                console.error('Record not found...');
                response.status(404).send({ error: "Record not found", requestBody: request.body });
            }
        }
        catch (error) {
            console.error('Error occurred...');
            response.status(400).send({ error: error.message, requestBody: request.body });
        }
    }
});

router.delete('/:id', [authorize, checkIfAdmin], async (request, response) => {
    console.log('Calling DELETE...');
    const genre = Genre.findById(request.params.id);
    if (genre) {
        try {
            const output = await Genre.findByIdAndDelete(request.params.id);
            response.send({ result: output, requestBody: request.body });
        }
        catch (error) {
            response.send({ result: error.message, requestBody: request.body });
        }
    }
    else {
        console.error('Record not found...');
        response.status(400).send({ error: result.error, requestBody: request.body });
    }
});

module.exports = router;