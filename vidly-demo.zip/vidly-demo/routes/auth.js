const express = require('express');
const router = express.Router();
const { User } = require('../models/user');
const bcrypt = require('bcrypt');
const Joi = require('joi');
const config = require('config');

router.post('/', async (request, response) => {
    console.log('Authenticating user...');
    const validation = validate(request.body);

    if (validation.error) {
        response.status(400).send({ result: validation.error });
    }
    else {
        let user = await User.findOne({ email: request.body.email });
        if (!user) return response.status(400).send({ result: "Invalid email or password!"});
        
        const result = await bcrypt.compare(request.body.password, user.password);
        if(!result) return response.status(400).send({ result: "Invalid email or password!"});

        const jwtToken = user.generateJwtToken();

        response.header('x-user-token', jwtToken).send(user);
    }
});

function validate(params) {
    console.log('Validating model...');
    const schema = Joi.object({
        email: Joi.string().min(5).max(255).required().email(),
        password: Joi.string().min(5).max(1024).required()
    })
    return schema.validate(params);
}


module.exports = router;