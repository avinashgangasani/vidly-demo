const express = require('express');
const router = express.Router();
const { Rental } = require('../models/rental');
const authorize = require('../middleware/authorization');

router.get('/', authorize, async (request, response) => {
    const rentals = await Rental.find();
    response.send({ result: rentals });
});

router.post('/', authorize, async (request, response) => {
    const rental = new Rental({
        customer: request.body.customer,
        movie: request.body.movie,
        dateOut: request.body.dateOut,
        dateReturned: request.body.dateReturned,
        rentalFee: request.body.rentalFee
    })
    const output = await rental.save();
    response.send({result: output});
});

module.exports = router;