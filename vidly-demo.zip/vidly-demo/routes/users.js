const express = require('express');
const router = express.Router();
const { User, validateUser } = require('../models/user');
const bcrypt = require('bcrypt');
const authorize = require('../middleware/authorization');

router.get('/me', authorize, async (request, response) => {
    const user = await User.findById(request.user._id).select("-password");
    response.send(user);
});

router.post('/register/', async (request, response) => {
    const validation = validateUser(request.body);

    if (validation.error) {
        response.status(400).send({ result: validation.error, requestBody: request.body });
    }
    else {
        let user = await User.findOne({ email: request.body.email });

        if (user) {
            response.status(400).send({ result: "User aleady exists!", requestBody: request.body });
        }
        else {
            try {
                user = new User({
                    name: request.body.name,
                    email: request.body.email,
                    password: request.body.password
                });
                
                const salt = await bcrypt.genSalt(10);
                user.password = await  bcrypt.hash(user.password, salt);

                await user.save();
                response.send({
                    result: { name: user.name, email: user.email },
                    requestBody: request.body
                });
            }
            catch (error) {
                response.send({ result: error.message, requestBody: request.body });
            }
        }
    }
});

module.exports = router;