//12 bytes
//first 4 bytes: timestamp
//next 3 bytes: machine identifier
//next 2 bytes: process identifier
//next 3 bytes: counter