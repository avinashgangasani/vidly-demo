const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/mongo-exercise',
    { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('Mongo DB connection established');
    })
    .catch((error) => {
        console.log('Connection failed...');
    });

const courseSchema = new mongoose.Schema({
    name: String,
    author: String,
    tags: [String],
    date: { type: Date, default: Date.now },
    isPublished: Boolean,
    price: Number
});
const Course = mongoose.model('Course', courseSchema);

async function getCourses() {
    const result = await Course.find({ isPublished: true })
        .or([
            { price: { $gte: 15 } },
            { name: /.*by.*/i }
        ])
        .sort('-price')
        .select('name author price');

    console.log(result);
}

//Update by query first approach
// async function updateCourse(idx) {
//     const course = await Course.findById(idx);

//     if (course) {
//         course.isPublished = true;
//         course.author = 'Avinash Reddy';
//         const result = await course.save();
//         console.log(result);
//     }
// }

//Update by update first approach
async function updateCourse(idx) {
    // const result = await Course.findByIdAndUpdate(mongoose.Types.ObjectId("5a68fe2142ae6a6482c4c9cb"), {$set: {
    //     isPublished: true,
    //     author: 'Avinash Reddy'
    // }}, { new: true });

    const result = await Course.findById(mongoose.Types.ObjectId("5a68fe2142ae6a6482c4c9cb"));

    console.log(result);
}


updateCourse('5a68fe2142ae6a6482c4c9cb');
//getCourses();