const genres = require('../routes/genres');
const homepage = require('../routes/homepage');
const customers = require('../routes/customers');
const movies = require('../routes/movies');
const rentals = require('../routes/rentals');
const users = require('../routes/users');
const auth = require('../routes/auth');
const errorlog = require('../middleware/errorlog');

module.exports = function routes(app) {
    app.use('/', homepage);
    app.use('/api/genres', genres);
    app.use('/api/customers', customers);
    app.use('/api/movies', movies);
    app.use('/api/rentals', rentals);
    app.use('/api/users', users);
    app.use('/api/login', auth);      
    
    //use error log after all middleware is called
    app.use(errorlog);
}

