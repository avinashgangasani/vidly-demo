const mongoose = require('mongoose');
const config = require('config');

module.exports = function() {
    let connection = config.get('db');
    mongoose.connect(connection,
    {
        useNewUrlParser: true,//to avoid warnings
        useUnifiedTopology: true//to avoid warnings
    }
)
    .then(() => {
        console.log(`DB Connection established via ${connection}.`);
    })
    .catch((err) => {
        console.error(err);
    })
}