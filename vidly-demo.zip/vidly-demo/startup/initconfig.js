const config = require("config");//Used to manage project configurations

module.exports = function(process, app) {
    if(!config.get('jwtPrivateKey')){
       throw new Error('FATAL error: JWT private key not set')
    }
    //const port = process.env.PORT || 3000;
    //process.env.NODE_ENV
    
    switch (app.get('env')) {
        case 'development':
            //console.log('This is DEV environment');
            break;
        case 'production':
            //console.log('This is PROD environment');
            break;
    }
    //console.log(app.get('env'));//Used to get NODE_ENV environment variable
    //console.log(`The configurations are from ${config.name} environment`);
    //console.log(`Mail password is ${config.password}. \nThis password is mapped to a pre-set environment variable name in custom-environment-variables.json file.`)    

    // app.listen(port, () => {
    // console.log(`Listening on port ${port}...`)
    // });
}