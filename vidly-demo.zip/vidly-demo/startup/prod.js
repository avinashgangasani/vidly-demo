const helmet = require('helmet');//used to protect the application from software vulverabilities
const compression = require('compression');//used to compress the http requests

module.exports = function(app) {
    app.use(helmet);
    app.use(compression);
}