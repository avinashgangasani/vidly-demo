module.exports = function(process) {
    
/*//For catching Error outside request pipeline
process.on('uncaughtException', (exception) => {
    console.log('We got an error outside Node request pipeline');
})

//For catching unhandled promise rejections
process.on('unhandledRejection', (rejection) => {
    console.log('We got an unhandled rejection');
 });
 
 const p = Promise.reject(new Error('Something failed badly'));
 p.then(() => console.log('Done'));
 
 throw new Error('Error outside request pipeline');*/
}